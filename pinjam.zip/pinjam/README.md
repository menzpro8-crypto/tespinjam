# README - Sistem Peminjaman Alat

Aplikasi web untuk mengelola peminjaman alat di sekolah/institusi.

## 📁 Struktur File

### Core Application
- **index.php** - Halaman login (entry point utama)
- **dashboard.php** - Dashboard utama (protected)
- **logout.php** - Logout (jangan dihapus)
- **api.php** - API endpoints (jangan dihapus)

### Configuration
- **config.php** - Konfigurasi database
- **cache.php** - Sistem cache

### Frontend
- **pinjam.css** - Stylesheet
- **pinjam.js** - JavaScript

### Database
- **init_db.php** - Inisialisasi database pertama kali
- **reset_db.php** - Reset database dengan data sample baru

### Folders
- **uploads/** - Folder untuk upload file
- **cache/** - Folder untuk cache files

---

## 🚀 Cara Menggunakan

### 1. Inisialisasi Database (Pertama Kali)
```
http://localhost/pinjam/init_db.php
```

### 2. Reset Database (Jika Ada Masalah)
```
http://localhost/pinjam/reset_db.php
```

### 3. Login ke Dashboard
```
http://localhost/pinjam/
```
atau
```
http://localhost/pinjam/index.php
```

**Default Credentials:**
- Username: `admin`
- Password: `admin123`

---

## 📊 Fitur Utama

### Dashboard
- Statistik jenis alat, total stock, peminjaman aktif
- Riwayat peminjaman terbaru
- Overview sistem

### Manajemen Data
- CRUD alat/equipment
- CRUD anggota/users
- CRUD peminjaman
- Notifikasi sistem

### Database
- MySQL dengan charset UTF-8MB4
- 5 tabel: admin, alat, anggota, peminjaman, notifications

---

## 🔧 Maintenance

### Jika Terjadi Error
1. Periksa koneksi MySQL
2. Akses `reset_db.php` untuk reset database
3. Login kembali dengan admin/admin123

### File yang Bisa Dihapus (Aman)
- `test_*.php` - Testing files
- `TODO.md` - Task list
- `query.txt` - Query sampel
- `check_db_status.php` - Debugging tool
- `audit_alat.php` - Audit tool

---

## 📝 Perbaikan yang Sudah Dilakukan

1. ✅ Fix charset di config.php (UTF-8MB4)
2. ✅ Fix sample data tanggal (2023 → 2025)
3. ✅ Fix ID alat yang tidak konsisten
4. ✅ Fix perhitungan dashboard stats
5. ✅ Tambah error handling & logging

---

**Last Updated:** November 12, 2025  
**Version:** 1.0.0
