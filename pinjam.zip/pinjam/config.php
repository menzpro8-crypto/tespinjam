<?php
// Database configuration
$host = 'localhost';
$dbname = 'pinjam_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    // Log error details for debugging
    error_log('Database connection error: ' . $e->getMessage() . ' (' . $e->getCode() . ')');
    
    // Display user-friendly error message
    if (php_sapi_name() === 'cli') {
        echo "Database connection failed: " . $e->getMessage() . "\n";
    } else {
        echo json_encode(['error' => 'Database connection failed. Please contact administrator.']);
    }
    exit();
}
?>
