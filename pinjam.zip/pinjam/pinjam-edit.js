/**
 * Edit Functions for Sistem Peminjaman Alat
 * File ini berisi semua fungsi untuk edit data
 */

// ===== EDIT ALAT =====
function editAlat(id) {
    console.log('editAlat called with ID:', id);
    
    // Fetch data dari API daripada dari local array (lebih reliable)
    fetch(`http://localhost/pinjam/api.php/alat/${id}`)
        .then(response => {
            console.log('Fetch response status:', response.status, response.ok);
            if (!response.ok) {
                return response.json().then(err => {
                    throw new Error(`HTTP error! status: ${response.status}, message: ${JSON.stringify(err)}`);
                });
            }
            return response.json();
        })
        .then(data => {
            console.log('Alat data fetched:', data);
            
            // Handle jika response adalah array
            const alat = Array.isArray(data) ? data[0] : data;
            
            if (!alat || (alat.error && !alat.nama)) {
                console.error('Invalid alat data:', alat);
                showCustomAlert('error', 'Error', 'Data alat tidak ditemukan atau tidak valid!');
                return;
            }

            console.log('Populating form with:', alat);
            
            // Populate form
            document.getElementById('editAlatId').value = alat.id;
            document.getElementById('editNamaAlat').value = alat.nama || '';
            document.getElementById('editDeskripsiAlat').value = alat.deskripsi || '';
            document.getElementById('editKategoriAlat').value = alat.kategori || '';
            document.getElementById('editStockAlat').value = alat.stock || 0;
            document.getElementById('editStatusAlat').value = alat.status || 'Tersedia';
            
            // Store original foto and show preview
            document.getElementById('editFotoAlatOld').value = alat.foto || '';
            if (alat.foto) {
                const preview = document.getElementById('editAlatImagePreview');
                preview.src = alat.foto;
                preview.style.display = 'block';
            }

            // Show modal
            console.log('Showing editAlatModal');
            const modal = document.getElementById('editAlatModal');
            if (modal) {
                showModal(modal);
                console.log('Modal shown successfully');
            } else {
                console.error('editAlatModal not found in DOM');
                showCustomAlert('error', 'Error', 'Modal form tidak ditemukan!');
            }
        })
        .catch(error => {
            console.error('Error in editAlat:', error);
            showCustomAlert('error', 'Error', 'Gagal mengambil data alat: ' + error.message);
        });
}

async function simpanEditAlat() {
    const id = document.getElementById('editAlatId').value;
    const nama = document.getElementById('editNamaAlat').value.trim();
    const deskripsi = document.getElementById('editDeskripsiAlat').value.trim();
    const kategori = document.getElementById('editKategoriAlat').value.trim();
    const stock = parseInt(document.getElementById('editStockAlat').value);
    const status = document.getElementById('editStatusAlat').value;
    const fotoInput = document.getElementById('editFotoAlat');
    const fotoOld = document.getElementById('editFotoAlatOld').value;

    // Validation
    if (!nama || !deskripsi || !kategori) {
        showCustomAlert('warning', 'Warning', 'Semua field harus diisi!');
        return;
    }

    if (stock < 0) {
        showCustomAlert('warning', 'Warning', 'Stock tidak boleh negatif!');
        return;
    }

    try {
        let foto = fotoOld; // Default: gunakan foto lama

        // Handle file upload jika ada file baru
        if (fotoInput.files && fotoInput.files.length > 0) {
            const file = fotoInput.files[0];
            
            // Validate file type
            if (!file.type.startsWith('image/')) {
                showCustomAlert('warning', 'Warning', 'File harus berupa gambar!');
                return;
            }

            // Validate file size (max 5MB)
            if (file.size > 5 * 1024 * 1024) {
                showCustomAlert('warning', 'Warning', 'Ukuran file tidak boleh lebih dari 5MB!');
                return;
            }

            // Upload file ke server
            const formData = new FormData();
            formData.append('file', file);
            formData.append('alat_id', id);

            console.log('Uploading file:', file.name);
            const uploadResponse = await fetch(`${API_BASE}/upload`, {
                method: 'POST',
                body: formData
            });

            const uploadResult = await uploadResponse.json();

            if (uploadResponse.ok && uploadResult.foto) {
                foto = uploadResult.foto;
                console.log('File uploaded successfully:', foto);
            } else {
                showCustomAlert('warning', 'Warning', 'Gagal upload gambar, menggunakan gambar lama');
                // Continue dengan foto lama jika upload gagal
            }
        }

        // Send to API
        const response = await fetch(`${API_BASE}/alat/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                nama: nama,
                deskripsi: deskripsi,
                kategori: kategori,
                stock: stock,
                status: status,
                foto: foto
            })
        });

        const result = await response.json();

        if (response.ok) {
            // Update local data
            const index = alatData.findIndex(a => a.id == id);
            if (index !== -1) {
                alatData[index] = { ...alatData[index], nama, deskripsi, kategori, stock, status, foto };
            }

            // Close modal and refresh
            closeAllModals();
            renderDataAlat();
            showCustomAlert('success', 'Berhasil!', 'Data alat berhasil diubah!');
        } else {
            showCustomAlert('error', 'Error', result.message || 'Gagal mengubah data alat!');
        }
    } catch (error) {
        console.error('Error:', error);
        showCustomAlert('error', 'Error', 'Terjadi kesalahan saat mengubah data!');
    }
}

// ===== EDIT ANGGOTA =====
function editAnggota(id) {
    // Find anggota data
    const anggota = anggotaData.find(a => a.id == id);
    if (!anggota) {
        showCustomAlert('error', 'Error', 'Data anggota tidak ditemukan!');
        return;
    }

    // Populate form
    document.getElementById('editAnggotaId').value = anggota.id;
    document.getElementById('editNamaAnggota').value = anggota.nama;
    document.getElementById('editKelasAnggota').value = anggota.kelas;
    document.getElementById('editKontakAnggota').value = anggota.kontak;
    document.getElementById('editStatusAnggota').value = anggota.status;

    // Show modal
    showModal(document.getElementById('editAnggotaModal'));
}

async function simpanEditAnggota() {
    const id = document.getElementById('editAnggotaId').value;
    const nama = document.getElementById('editNamaAnggota').value.trim();
    const kelas = document.getElementById('editKelasAnggota').value.trim();
    const kontak = document.getElementById('editKontakAnggota').value.trim();
    const status = document.getElementById('editStatusAnggota').value;

    // Validation
    if (!nama || !kelas || !kontak) {
        showCustomAlert('warning', 'Warning', 'Semua field harus diisi!');
        return;
    }

    try {
        // Send to API
        const response = await fetch(`${API_BASE}/anggota/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                nama: nama,
                kelas: kelas,
                kontak: kontak,
                status: status
            })
        });

        const result = await response.json();

        if (response.ok) {
            // Update local data
            const index = anggotaData.findIndex(a => a.id == id);
            if (index !== -1) {
                anggotaData[index] = { ...anggotaData[index], nama, kelas, kontak, status };
            }

            // Close modal and refresh
            closeAllModals();
            renderDataAnggota();
            showCustomAlert('success', 'Berhasil!', 'Data anggota berhasil diubah!');
        } else {
            showCustomAlert('error', 'Error', result.message || 'Gagal mengubah data anggota!');
        }
    } catch (error) {
        console.error('Error:', error);
        showCustomAlert('error', 'Error', 'Terjadi kesalahan saat mengubah data!');
    }
}

// ===== EDIT PEMINJAMAN =====
function editPeminjaman(id) {
    // Find peminjaman data
    const peminjaman = peminjamanData.find(p => p.id == id);
    if (!peminjaman) {
        showCustomAlert('error', 'Error', 'Data peminjaman tidak ditemukan!');
        return;
    }

    // Populate form
    document.getElementById('editPeminjamanId').value = peminjaman.id;
    document.getElementById('editNamaAlatPeminjaman').value = peminjaman.nama_alat;
    document.getElementById('editPeminjamEdit').value = peminjaman.peminjam;
    document.getElementById('editTanggalMulaiEdit').value = peminjaman.tanggal_mulai;
    document.getElementById('editTanggalSelesaiEdit').value = peminjaman.tanggal_selesai;
    document.getElementById('editStatusPeminjamanEdit').value = peminjaman.status;
    document.getElementById('editKeteranganEdit').value = peminjaman.keterangan || '';

    // Show modal
    showModal(document.getElementById('editPeminjamanModal'));
}

async function simpanEditPeminjaman() {
    const id = document.getElementById('editPeminjamanId').value;
    const tanggalMulai = document.getElementById('editTanggalMulaiEdit').value;
    const tanggalSelesai = document.getElementById('editTanggalSelesaiEdit').value;
    const status = document.getElementById('editStatusPeminjamanEdit').value;
    const keterangan = document.getElementById('editKeteranganEdit').value.trim();

    // Validation
    if (!tanggalMulai || !tanggalSelesai) {
        showCustomAlert('warning', 'Warning', 'Tanggal harus diisi!');
        return;
    }

    if (new Date(tanggalMulai) > new Date(tanggalSelesai)) {
        showCustomAlert('warning', 'Warning', 'Tanggal selesai harus lebih besar dari tanggal mulai!');
        return;
    }

    try {
        // Send to API
        const response = await fetch(`${API_BASE}/peminjaman/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                tanggal_mulai: tanggalMulai,
                tanggal_selesai: tanggalSelesai,
                status: status,
                keterangan: keterangan
            })
        });

        const result = await response.json();

        if (response.ok) {
            // Update local data
            const index = peminjamanData.findIndex(p => p.id == id);
            if (index !== -1) {
                peminjamanData[index] = { 
                    ...peminjamanData[index], 
                    tanggal_mulai: tanggalMulai,
                    tanggal_selesai: tanggalSelesai,
                    status: status,
                    keterangan: keterangan
                };
            }

            // Close modal and refresh
            closeAllModals();
            renderPeminjaman();
            showCustomAlert('success', 'Berhasil!', 'Data peminjaman berhasil diubah!');
        } else {
            showCustomAlert('error', 'Error', result.message || 'Gagal mengubah data peminjaman!');
        }
    } catch (error) {
        console.error('Error:', error);
        showCustomAlert('error', 'Error', 'Terjadi kesalahan saat mengubah data!');
    }
}
