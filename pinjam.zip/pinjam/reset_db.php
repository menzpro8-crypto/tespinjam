<?php
/**
 * Database Reset Script
 * Access via browser: http://localhost/pinjam/reset_db.php
 * WARNING: This will DELETE all data and reinitialize the database!
 */

// Check if accessed via CLI
if (php_sapi_name() === 'cli') {
    echo "This script must be accessed via a web browser.\n";
    echo "Visit: http://localhost/pinjam/reset_db.php\n";
    exit();
}

// HTML output for web browser
?>
<!DOCTYPE html>
<html>
<head>
    <title>Database Reset</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 5px; }
        .log { background: #f0f0f0; padding: 15px; border-radius: 3px; font-family: monospace; white-space: pre-wrap; margin-top: 20px; }
        .success { color: green; }
        .error { color: red; }
        .warning { color: orange; }
        h1 { color: #333; }
        .button-group { margin-top: 20px; }
        button { padding: 10px 20px; margin-right: 10px; cursor: pointer; }
        .btn-danger { background: #ff4444; color: white; border: none; border-radius: 4px; }
        .btn-danger:hover { background: #cc0000; }
        .btn-secondary { background: #cccccc; color: black; border: none; border-radius: 4px; }
        .btn-secondary:hover { background: #999999; }
    </style>
</head>
<body>
    <div class="container">
        <h1>⚠️ Database Reset Warning</h1>
        <p><strong>WARNING:</strong> This will DELETE all tables and data in the database!</p>
        
        <?php
        // Check if reset confirmation is provided
        $confirmReset = isset($_POST['confirm_reset']) && $_POST['confirm_reset'] === 'yes';
        
        if ($confirmReset) {
            // Database configuration
            $host = 'localhost';
            $dbname = 'pinjam_db';
            $username = 'root';
            $password = '';

            // Connect to database
            try {
                $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                echo '<div class="log">' . "\n";
                echo '<span class="success">✓ Database connection successful.</span>' . "\n\n";
                
                // Drop all tables
                echo '<strong>Dropping existing tables...</strong>' . "\n";
                $tables = ['peminjaman', 'anggota', 'notifications', 'admin', 'alat'];
                foreach ($tables as $table) {
                    try {
                        $pdo->exec("DROP TABLE IF EXISTS `$table`");
                        echo '<span class="success">✓ Dropped table: ' . $table . '</span>' . "\n";
                    } catch(PDOException $e) {
                        echo '<span class="error">✗ Error dropping table: ' . htmlspecialchars($e->getMessage()) . '</span>' . "\n";
                    }
                }
                
                echo "\n<strong>Creating new tables...</strong>\n";
                
                // Create tables
                $tables = [
                    "CREATE TABLE IF NOT EXISTS alat (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        nama VARCHAR(255) NOT NULL,
                        deskripsi TEXT,
                        kategori VARCHAR(100),
                        stock INT DEFAULT 0,
                        status ENUM('Tersedia', 'Tidak Tersedia') DEFAULT 'Tersedia',
                        foto VARCHAR(500),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        INDEX idx_nama (nama),
                        INDEX idx_kategori (kategori),
                        INDEX idx_stock (stock),
                        INDEX idx_status (status)
                    )",

                    "CREATE TABLE IF NOT EXISTS anggota (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        nama VARCHAR(255) NOT NULL,
                        kelas VARCHAR(100),
                        kontak VARCHAR(50),
                        status ENUM('Aktif', 'Tidak Aktif') DEFAULT 'Aktif',
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        INDEX idx_nama (nama),
                        INDEX idx_kelas (kelas),
                        INDEX idx_status (status)
                    )",

                    "CREATE TABLE IF NOT EXISTS peminjaman (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        alat_id INT NOT NULL,
                        nama_alat VARCHAR(255) NOT NULL,
                        peminjam VARCHAR(255) NOT NULL,
                        tanggal_mulai DATE NOT NULL,
                        tanggal_selesai DATE NOT NULL,
                        status ENUM('Aktif', 'Selesai', 'Terlambat') DEFAULT 'Aktif',
                        keterangan TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        FOREIGN KEY (alat_id) REFERENCES alat(id) ON DELETE CASCADE,
                        INDEX idx_alat_id (alat_id),
                        INDEX idx_status (status),
                        INDEX idx_peminjam (peminjam),
                        INDEX idx_tanggal_mulai (tanggal_mulai),
                        INDEX idx_tanggal_selesai (tanggal_selesai)
                    )",

                    "CREATE TABLE IF NOT EXISTS notifications (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        type ENUM('warning', 'error', 'info', 'success') NOT NULL,
                        title VARCHAR(255) NOT NULL,
                        message TEXT NOT NULL,
                        time VARCHAR(100),
                        is_read BOOLEAN DEFAULT FALSE,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                    )",

                    "CREATE TABLE IF NOT EXISTS admin (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        username VARCHAR(50) NOT NULL UNIQUE,
                        password VARCHAR(255) NOT NULL,
                        nama VARCHAR(100) NOT NULL,
                        email VARCHAR(100),
                        status ENUM('Aktif', 'Tidak Aktif') DEFAULT 'Aktif',
                        last_login TIMESTAMP NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        INDEX idx_username (username),
                        INDEX idx_status (status)
                    )"
                ];

                foreach ($tables as $table) {
                    try {
                        $pdo->exec($table);
                        echo '<span class="success">✓ Table created successfully.</span>' . "\n";
                    } catch(PDOException $e) {
                        echo '<span class="error">✗ Error creating table: ' . htmlspecialchars($e->getMessage()) . '</span>' . "\n";
                    }
                }

                echo "\n<strong>Inserting sample data...</strong>\n";

                // Insert sample data
                $sampleData = [
                    "INSERT INTO alat (nama, deskripsi, kategori, stock, status, foto) VALUES
                    ('Laptop Dell XPS 15', 'Laptop untuk desain grafis dan programming dengan spesifikasi tinggi', 'Elektronik', 3, 'Tersedia', 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=500&h=300&fit=crop'),
                    ('Proyektor Epson', 'Proyektor untuk presentasi dengan resolusi HD', 'Elektronik', 3, 'Tersedia', 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=500&h=300&fit=crop'),
                    ('Kamera Canon EOS 80D', 'Kamera DSLR untuk fotografi profesional', 'Fotografi', 3, 'Tersedia', 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=500&h=300&fit=crop'),
                    ('Mikrofon Rode NT1', 'Mikrofon kondenser untuk rekaman studio', 'Audio', 3, 'Tersedia', 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=500&h=300&fit=crop'),
                    ('Tablet iPad Pro 12.9\"', 'Tablet premium untuk kreativitas dan produktivitas', 'Elektronik', 2, 'Tersedia', 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=500&h=300&fit=crop'),
                    ('Speaker Bluetooth JBL', 'Speaker portabel dengan kualitas suara tinggi', 'Audio', 5, 'Tersedia', 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=500&h=300&fit=crop'),
                    ('Drone DJI Mini 3', 'Drone ringan untuk fotografi udara dan videografi', 'Fotografi', 1, 'Tersedia', 'https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=500&h=300&fit=crop'),
                    ('Monitor LG 27\"', 'Monitor 4K untuk editing video dan desain', 'Elektronik', 4, 'Tersedia', 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=500&h=300&fit=crop'),
                    ('Headphone Sony WH-1000XM4', 'Headphone noise-cancelling untuk musik dan panggilan', 'Audio', 0, 'Tidak Tersedia', 'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=500&h=300&fit=crop')",

                    "INSERT INTO anggota (nama, kelas, kontak, status) VALUES
                    ('Ahmad Rahman', 'XII RPL 1', '081234567890', 'Aktif'),
                    ('Siti Nurhaliza', 'XII RPL 2', '081234567891', 'Aktif'),
                    ('Budi Santoso', 'XII TKJ 1', '081234567892', 'Aktif'),
                    ('Maya Sari', 'XII MM 1', '081234567893', 'Aktif'),
                    ('Rizki Pratama', 'XII RPL 1', '081234567894', 'Aktif'),
                    ('Dewi Lestari', 'XII TKJ 2', '081234567895', 'Aktif'),
                    ('Fajar Nugroho', 'XII MM 2', '081234567896', 'Aktif'),
                    ('Intan Permata', 'XII RPL 2', '081234567897', 'Aktif'),
                    ('Gilang Ramadhan', 'XII TKJ 1', '081234567898', 'Aktif'),
                    ('Nadia Putri', 'XII MM 1', '081234567899', 'Aktif')",

                    "INSERT INTO peminjaman (alat_id, nama_alat, peminjam, tanggal_mulai, tanggal_selesai, status) VALUES
                    (2, 'Proyektor Epson', 'Budi Santoso', '2025-11-10', '2025-11-15', 'Aktif'),
                    (3, 'Kamera Canon EOS 80D', 'Siti Nurhaliza', '2025-11-05', '2025-11-08', 'Selesai'),
                    (1, 'Laptop Dell XPS 15', 'Ahmad Rahman', '2025-10-25', '2025-10-28', 'Selesai'),
                    (4, 'Mikrofon Rode NT1', 'Maya Sari', '2025-10-20', '2025-10-24', 'Selesai'),
                    (5, 'Tablet iPad Pro 12.9\"', 'Rizki Pratama', '2025-10-15', '2025-10-19', 'Selesai'),
                    (6, 'Speaker Bluetooth JBL', 'Dewi Lestari', '2025-10-10', '2025-10-13', 'Selesai'),
                    (8, 'Monitor LG 27\"', 'Fajar Nugroho', '2025-10-05', '2025-10-09', 'Selesai'),
                    (7, 'Drone DJI Mini 3', 'Intan Permata', '2025-10-01', '2025-10-04', 'Selesai'),
                    (2, 'Proyektor Epson', 'Gilang Ramadhan', '2025-09-25', '2025-09-28', 'Selesai'),
                    (1, 'Laptop Dell XPS 15', 'Nadia Putri', '2025-09-20', '2025-09-24', 'Selesai')",

                    "INSERT INTO admin (username, password, nama, email, status) VALUES
                    ('admin', '" . password_hash('admin123', PASSWORD_DEFAULT) . "', 'Administrator', 'admin@smkalbasthomi.sch.id', 'Aktif')"
                ];

                foreach ($sampleData as $data) {
                    try {
                        $pdo->exec($data);
                        echo '<span class="success">✓ Sample data inserted successfully.</span>' . "\n";
                    } catch(PDOException $e) {
                        echo '<span class="error">✗ Error inserting sample data: ' . htmlspecialchars($e->getMessage()) . '</span>' . "\n";
                    }
                }

                echo "\n";
                echo '<span class="success"><strong>✓ Database reset completed!</strong></span>' . "\n";
                echo "\n<a href='index.php'>Go to Login Page</a>";
                
                echo "</div>";
            } catch(PDOException $e) {
                echo '<span class="error">✗ Error: ' . htmlspecialchars($e->getMessage()) . '</span>' . "\n";
            }
        } else {
            // Show confirmation form
            echo '<form method="POST" style="margin-top: 20px;">' . "\n";
            echo '<p><strong>Are you sure you want to reset the database?</strong></p>' . "\n";
            echo '<p>This action will:</p>' . "\n";
            echo '<ul>' . "\n";
            echo '<li>Delete all existing tables</li>' . "\n";
            echo '<li>Delete all data</li>' . "\n";
            echo '<li>Recreate all tables with fresh sample data</li>' . "\n";
            echo '</ul>' . "\n";
            echo '<p><strong style="color: red;">This cannot be undone!</strong></p>' . "\n";
            echo '<div class="button-group">' . "\n";
            echo '<button type="submit" class="btn-danger" onclick="this.form.confirm_reset.value=\'yes\'">Reset Database</button>' . "\n";
            echo '<input type="hidden" name="confirm_reset" value="no">' . "\n";
            echo '<a href="index.php"><button type="button" class="btn-secondary">Cancel</button></a>' . "\n";
            echo '</div>' . "\n";
            echo '</form>' . "\n";
        }
        ?>
    </div>
</body>
</html>
